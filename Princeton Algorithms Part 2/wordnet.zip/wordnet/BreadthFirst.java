import edu.princeton.cs.algs4.Digraph;
import edu.princeton.cs.algs4.Queue;

import java.util.Arrays;

public class BreadthFirst {

    private Queue<Integer> q;
    private boolean [] visited;
    private int [] distTo;
    private int vertices;
    BreadthFirst(Digraph g, int source) {

        if (source < 0 || source > g.V()) throw new IllegalArgumentException();
        this.vertices = g.V();
        q = new Queue<>();
        visited = new boolean[g.V()];
        distTo = new int[g.V()];

        Arrays.fill(visited, false);
        bfs(g, source);
    }

    private void bfs(Digraph g, int s) {
        Queue<Integer> tq = new Queue<>();
        tq.enqueue(s);
        visited[s] = true;

        while (!tq.isEmpty()) {
            s = tq.dequeue();
            q.enqueue(s);
            for (int vertex : g.adj(s)) {
                if (!visited[vertex]) {
                    visited[vertex] = true;
                    distTo[vertex] = distTo[s] + 1;
                    tq.enqueue(vertex);
                }
            }
        }
    }

    public int distTo(int v) {
        if (v < 0 || v > vertices) throw new IllegalArgumentException();
        return distTo[v];
    }

    public Queue<Integer> traversal() {
        return q;
    }

    public static void main(String[] args) {

    }
}
