import edu.princeton.cs.algs4.Digraph;
import edu.princeton.cs.algs4.In;
import edu.princeton.cs.algs4.StdIn;
import edu.princeton.cs.algs4.StdOut;
import edu.princeton.cs.algs4.Queue;
import edu.princeton.cs.algs4.RandomSeq;

public class SAP {

    private Digraph G;
    private int groupAncestor = -1;

    // constructor takes a digraph (not necessarily a DAG)
    public SAP(Digraph G) {
        if (G == null) throw new IllegalArgumentException();
        this.G = new Digraph(G);
    }

    // length of shortest ancestral path between v and w; -1 if no such path
    public int length(int v, int w) {

        if (v < 0 || v > G.V()) throw new IllegalArgumentException();
        if (w < 0 || w > G.V()) throw new IllegalArgumentException();

        if (v == w) return 0;
        BreadthFirst bfsV = new BreadthFirst(G, v);
        Queue<Integer> sV = bfsV.traversal();

        BreadthFirst bfsW = new BreadthFirst(G, w);
        Queue<Integer> sW = bfsW.traversal();

        int ancestor = -1;
        int pathLen = Integer.MAX_VALUE;
        for (int fw : sW) {
            for (int fv : sV) {
                if (fw == fv) {
                    if (ancestor == -1) {
                        ancestor = fw;
                        pathLen = bfsV.distTo(ancestor) + bfsW.distTo(ancestor);
                    }
                    else {
                        if (pathLen > bfsV.distTo(fw) + bfsW.distTo(fw)) {
                            ancestor = fw;
                            pathLen = bfsV.distTo(fw) + bfsW.distTo(fw);
                        }
                    }
                }
            }
        }

        if (ancestor == -1) return -1;
        int dv = bfsV.distTo(ancestor);
        int dw = bfsW.distTo(ancestor);
        return dv + dw;
    }

    // a common ancestor of v and w that participates in a shortest ancestral path; -1 if no such path
    public int ancestor(int v, int w) {

        if (v < 0 || v > G.V()) throw new IllegalArgumentException();
        if (w < 0 || w > G.V()) throw new IllegalArgumentException();

        if (v == w) return v;
        BreadthFirst bfsV = new BreadthFirst(G, v);
        Queue<Integer> sV = bfsV.traversal();

        BreadthFirst bfsW = new BreadthFirst(G, w);
        Queue<Integer> sW = bfsW.traversal();

        int ancestor = -1;
        int pathLen = Integer.MAX_VALUE;
        for (int fw : sW) {
            for (int fv : sV) {
                if (fw == fv) {
                    if (ancestor == -1) {
                        ancestor = fw;
                        pathLen = bfsV.distTo(ancestor) + bfsW.distTo(ancestor);
                    }
                    else {
                        if (pathLen > bfsV.distTo(fw) + bfsW.distTo(fw)) {
                            ancestor = fw;
                            pathLen = bfsV.distTo(fw) + bfsW.distTo(fw);
                        }
                    }
                }
            }
        }
        return ancestor;
    }

    // length of shortest ancestral path between any vertex in v and any vertex in w; -1 if no such path
    public int length(Iterable<Integer> v, Iterable<Integer> w) {
        if (v == null || w == null) throw new IllegalArgumentException();
        int len = Integer.MAX_VALUE;
        // int anc = -1;
        for (int i : v) {
            for (int j : w) {
                int currentLen = length(i, j);
                int currentAncestor = ancestor(i, j);
                if (currentLen != 0 && len > currentLen) {
                    groupAncestor = currentAncestor;
                    len = currentLen;
                }
            }
        }
        if (len == Integer.MAX_VALUE) return -1;
        return len;
    }
    //
    // a common ancestor that participates in shortest ancestral path; -1 if no such path
    public int ancestor(Iterable<Integer> v, Iterable<Integer> w) {
        if (v == null || w == null) throw new IllegalArgumentException();
        length(v, w);
        return groupAncestor;
    }

    // do unit testing of this class
    public static void main(String[] args) {
        String filename = args[0];
        In in = new In(filename);

        Digraph g = new Digraph(in);
        SAP sp = new SAP(g);

        while (!StdIn.isEmpty()) {
            int v = StdIn.readInt();
            int w = StdIn.readInt();
            int length   = sp.length(v, w);
            int ancestor = sp.ancestor(v, w);
            StdOut.printf("length = %d, ancestor = %d\n", length, ancestor);
        }

        int v = 0, w = 3;
        System.out.println("Ancestor: " + sp.ancestor(v, w));
        System.out.println("Length: " + sp.length(v, w));


        // Queue<Integer> a = new Queue<>();
        // a.enqueue(13); a.enqueue(23); a.enqueue(24);
        //
        // Queue<Integer> b = new Queue<>();
        // b.enqueue(6); b.enqueue(16); b.enqueue(17);
        //
        // System.out.println("Ancestor: " + sp.ancestor(a, b));
        // System.out.println("Length: " + sp.length(a, b));
    }
}