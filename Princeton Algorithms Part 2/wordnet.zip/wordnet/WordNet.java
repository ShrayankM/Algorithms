import edu.princeton.cs.algs4.Digraph;
import edu.princeton.cs.algs4.In;
import edu.princeton.cs.algs4.Queue;
import edu.princeton.cs.algs4.SET;
import edu.princeton.cs.algs4.StdIn;
import edu.princeton.cs.algs4.StdOut;

import java.util.TreeMap;

public class WordNet {

    private Digraph G;
    private TreeMap<String, SET<Integer>> nounMap;
    private TreeMap<Integer, String> check;
    // constructor takes the name of the two input files
    public WordNet(String synsets, String hypernyms) {

        if (synsets == null || hypernyms == null) throw new IllegalArgumentException();
        In in = new In(synsets);

        nounMap = new TreeMap<>();
        check = new TreeMap<>();

        while (!in.isEmpty()) {
            String [] str = in.readLine().split(",");
            int id = Integer.parseInt(str[0]);
            String noun = str[1];

            SET<Integer> temp = nounMap.get(noun);
            if (temp == null) {
                temp = new SET<>();
            }
            temp.add(id);
            nounMap.put(noun, temp);
            check.put(id, noun);
        }

        // G = new Digraph(nounMap.size());
        G = new Digraph(90000);

        in = new In(hypernyms);
        while (!in.isEmpty()) {
            String [] str = in.readLine().split(",");
            int id = Integer.parseInt(str[0]);
            int v = id;
            for (int i = 1; i < str.length; i++) {
                int w = Integer.parseInt(str[i]);
                G.addEdge(v, w);
            }
        }
    }

    // returns all WordNet nouns
    public Iterable<String> nouns() {
        return nounMap.keySet();
    }

    // is the word a WordNet noun?
    public boolean isNoun(String word) {
        if (word == null) throw new IllegalArgumentException();
        return nounMap.containsKey(word);
    }

    // distance between nounA and nounB (defined below)
    public int distance(String nounA, String nounB) {

        if (nounA == null || nounB == null) throw new IllegalArgumentException();
        Queue<Integer> a = new Queue<>();
        Queue<Integer> b = new Queue<>();

        for (int id : check.keySet()) {
            String forId = check.get(id);
            if (forId.contains(nounA)) a.enqueue(id);
            if (forId.contains(nounB)) b.enqueue(id);
        }
        // SET<Integer> a = nounMap.get(nounA);
        // SET<Integer> b = nounMap.get(nounB);

        SAP sp = new SAP(G);
        return sp.length(a, b);
    }

    // a synset (second field of synsets.txt) that is the common ancestor of nounA and nounB
    // in a shortest ancestral path (defined below)
    public String sap(String nounA, String nounB) {

        if (nounA == null || nounB == null) throw new IllegalArgumentException();
        Queue<Integer> a = new Queue<>();
        Queue<Integer> b = new Queue<>();

        for (int id : check.keySet()) {
            String forId = check.get(id);
            if (forId.contains(nounA)) a.enqueue(id);
            if (forId.contains(nounB)) b.enqueue(id);
        }

        SAP sp = new SAP(G);
        int anc =  sp.ancestor(a, b);

        String str = check.get(anc);
        return str;
    }

    // do unit testing of this class
    public static void main(String[] args) {
        String syn = args[0];
        String hyn = args[1];
        WordNet wn = new WordNet(syn, hyn);

        for (String str : wn.nounMap.keySet()) {
            System.out.print("Key = " + str + " Value = " + wn.nounMap.get(str) + "\n");
        }

        while (!StdIn.isEmpty()) {
            String v = StdIn.readString();
            String w = StdIn.readString();
            int length   = wn.distance(v, w);
            String ancestor = wn.sap(v, w);
            StdOut.printf("length = %d, ancestor = %s\n", length, ancestor);
        }

        String v = "e", w = "h";
        System.out.println("Distance = " + wn.distance(v, w));
        System.out.println("Ancestor = " + wn.sap(v, w));
    }
}